Sajid's Study Tracker - Android alarm app
GitHub এ সব ফাইল আপলোড করো -> Actions ট্যাব -> Build APK -> Artifacts থেকে SajidStudyTracker-APK ডাউনলোড।

v6 (ব্রাউজার আপডেট): শর্টকাট ড্র্যাগ করে সরানো, Site settings > All sites, পাসওয়ার্ড (ফোন লক দিয়ে), থিম (Light/Dark/System),
সার্চ ইঞ্জিন ১০টা, YouTube/ভিডিও ডাউনলোড (কোয়ালিটি লিস্ট + রিনেম), ছবি সবসময় অরিজিনাল, ব্রাউজারের সব লেখা ইংরেজি ও আইকনহীন।
