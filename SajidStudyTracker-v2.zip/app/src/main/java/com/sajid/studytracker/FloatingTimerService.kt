package com.sajid.studytracker

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

// অ্যাপের কোন স্ক্রিন সামনে আছে এবং টাইমারের সর্বশেষ অবস্থা (JS থেকে আসে)
object TimerState {
    @Volatile var mainVisible = false
    @Volatile var visibleCount = 0   // অ্যাপের (মূল স্ক্রিন বা ব্রাউজার) কতগুলো স্ক্রিন এখন চোখের সামনে
    @Volatile var mode = ""          // "down" = কাউন্টডাউন, "up" = স্টপওয়াচ, "" = কোনো টাইমার চলছে না
    @Volatile var baseMs = 0L
    @Volatile var syncedAt = 0L

    fun set(m: String, ms: Long) { baseMs = ms; syncedAt = System.currentTimeMillis(); mode = m }

    fun currentMs(): Long {
        val el = System.currentTimeMillis() - syncedAt
        return if (mode == "down") maxOf(0L, baseMs - el) else baseMs + el
    }

    fun format(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }
}

// টাইমার চলাকালে অ্যাপের বাইরে গেলে (বা অ্যাপের ভেতরের ব্রাউজারে গেলে) ছোট গোল ভাসমান টাইমার দেখায়
class FloatingTimerService : Service() {
    companion object {
        @Volatile var running = false
        fun canOverlay(c: Context) = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)
    }

    private val h = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var closeTarget: TextView? = null
    private var dismissed = false   // ক্লোজ করা হলে অ্যাপে ফেরা পর্যন্ত বাবল লুকানো থাকে (টাইমার চলতেই থাকে)

    private val tick = object : Runnable {
        override fun run() {
            if (TimerState.mode.isEmpty()) { stopSelf(); return }
            if (TimerState.mainVisible) dismissed = false
            val show = !TimerState.mainVisible && !dismissed && canOverlay(this@FloatingTimerService)
            if (show) {
                ensureBubble()
                bubble?.text = TimerState.format(TimerState.currentMs())
            } else removeBubble()
            h.postDelayed(this, 500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        running = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel("timer_bubble", "চলমান টাইমার", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 8, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, "timer_bubble")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏱ টাইমার চলছে")
            .setContentText("চাপ দিয়ে অ্যাপে ফিরে যাও")
            .setOngoing(true).setSilent(true).setContentIntent(open).build()
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            ServiceCompat.startForeground(this, 21, n, type)
        } catch (e: Exception) { try { startForeground(21, n) } catch (e2: Exception) { } }
        h.removeCallbacks(tick); h.post(tick)
        return START_NOT_STICKY
    }

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun ensureBubble() {
        if (bubble != null) return
        try {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val size = dp(78f)
            val tv = TextView(this).apply {
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#E61B5E20"))
                    setStroke(dp(3f), Color.parseColor("#66BB6A"))
                }
                elevation = dp(6f).toFloat()
            }
            val sp = getSharedPreferences("bubble", Context.MODE_PRIVATE)
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else WindowManager.LayoutParams.TYPE_PHONE
            val p = WindowManager.LayoutParams(
                size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = sp.getInt("x", dp(16f)); y = sp.getInt("y", dp(140f))
            }
            tv.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                            if (Math.abs(dx) > dp(6f) || Math.abs(dy) > dp(6f)) moved = true
                            if (moved) {
                                val (sw, sh) = screenSize()
                                // পুরো স্ক্রিনের যেকোনো জায়গায় নেওয়া যাবে (কিনারা পর্যন্ত)
                                p.x = (ox + dx).coerceIn(0, maxOf(0, sw - size))
                                p.y = (oy + dy).coerceIn(0, maxOf(0, sh - size))
                                try { wm?.updateViewLayout(tv, p) } catch (x: Exception) { }
                                showCloseTarget(nearClose(p.x + size / 2, p.y + size / 2))
                            }
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            val onClose = moved && nearClose(p.x + size / 2, p.y + size / 2)
                            hideCloseTarget()
                            if (onClose) { dismissed = true; removeBubble() }   // টাইমার চলতে থাকে, শুধু বাবল সরে যায়
                            else if (moved) sp.edit().putInt("x", p.x).putInt("y", p.y).apply()
                            else if (e.action == MotionEvent.ACTION_UP) openApp()
                        }
                    }
                    return true
                }
            })
            wm?.addView(tv, p)
            bubble = tv; lp = p
        } catch (e: Exception) { bubble = null }
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val m = android.util.DisplayMetrics()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    // ক্লোজ জায়গার কেন্দ্র: স্ক্রিনের নিচের মাঝখানে
    private fun nearClose(cx: Int, cy: Int): Boolean {
        val (sw, sh) = screenSize()
        val tx = sw / 2; val ty = sh - dp(60f) - dp(32f)
        val dx = (cx - tx).toDouble(); val dy = (cy - ty).toDouble()
        return Math.sqrt(dx * dx + dy * dy) < dp(80f)
    }

    private fun showCloseTarget(active: Boolean) {
        try {
            if (closeTarget == null) {
                val t = TextView(this).apply {
                    text = "✕"; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                }
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                           else WindowManager.LayoutParams.TYPE_PHONE
                val lp2 = WindowManager.LayoutParams(
                    dp(64f), dp(64f), type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = dp(60f) }
                wm?.addView(t, lp2)
                closeTarget = t
            }
            closeTarget?.let {
                it.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(if (active) "#EEE53935" else "#99000000"))
                    setStroke(dp(2f), Color.WHITE)
                }
                val sc = if (active) 1.3f else 1f
                it.scaleX = sc; it.scaleY = sc
            }
        } catch (e: Exception) { }
    }

    private fun hideCloseTarget() {
        closeTarget?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
        closeTarget = null
    }

    private fun removeBubble() {
        hideCloseTarget()
        bubble?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
        bubble = null
    }

    // বাবলে চাপ দিলে অ্যাপে ফেরা (ভেতরের ব্রাউজার খোলা থাকলে সেটা বন্ধ হয়ে যাবে)
    private fun openApp() {
        try { BrowserActivity.cur?.finish() } catch (e: Exception) { }
        try {
            startActivity(Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacks(tick)
        removeBubble()
        super.onDestroy()
    }
}
