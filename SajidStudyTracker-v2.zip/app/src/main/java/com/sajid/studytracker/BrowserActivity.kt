package com.sajid.studytracker

import android.app.DownloadManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.os.Message
import android.view.Gravity
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

// অ্যাপের ভেতরের ব্রাউজার — যেকোনো ওয়েব লিংক এখানেই খোলে
class BrowserActivity : AppCompatActivity() {
    companion object { @Volatile var cur: BrowserActivity? = null }

    private lateinit var web: WebView
    private lateinit var urlText: TextView
    private lateinit var bar: ProgressBar
    private lateinit var frame: FrameLayout
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    private fun showUrl(u: String?) {
        if (u.isNullOrBlank() || u == "about:blank") return
        urlText.text = (if (u.startsWith("https://")) "🔒 " else "") + u
    }

    // ফোনের যেকোনো ব্রাউজারে খোলার অপশন
    private fun openExternal() {
        val u = web.url ?: intent.getStringExtra("url") ?: return
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW, Uri.parse(u)), "যে ব্রাউজারে খুলবে সেটা বাছো"))
        } catch (e: Exception) { Toast.makeText(this, "কোনো ব্রাউজার পাওয়া যায়নি", Toast.LENGTH_SHORT).show() }
    }


    // ---------- ব্রাউজারের বাড়তি ফিচার: ইতিহাস, ডাউনলোড, ভিডিও/অডিও, কুকিজ, ডেস্কটপ মোড ----------
    private val hp by lazy { getSharedPreferences("browser", MODE_PRIVATE) }
    private val found = java.util.Collections.synchronizedMap(LinkedHashMap<String, String>())
    private val mediaExt = Regex("\\.(mp4|webm|mkv|m4v|mov|3gp|mp3|m4a|aac|ogg|opus|wav|flac)(\\?|#|$)", RegexOption.IGNORE_CASE)
    private val scanJs = "(function(){var o=[];document.querySelectorAll('video,audio,source').forEach(function(e){var s=e.currentSrc||e.src;if(s&&s.indexOf('http')==0)o.push(s);});return JSON.stringify(o);})()"
    private var desktop = false
    private var mobileUa = ""
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun addHistory(title: String?, url: String?) {
        if (url.isNullOrBlank() || !url.startsWith("http")) return
        try {
            val old = JSONArray(hp.getString("history", "[]"))
            if (old.length() > 0 && old.getJSONObject(0).optString("u") == url) return
            val neu = JSONArray()
            neu.put(JSONObject().put("t", if (title.isNullOrBlank()) url else title).put("u", url).put("ts", System.currentTimeMillis()))
            for (k in 0 until minOf(old.length(), 499)) neu.put(old.getJSONObject(k))
            hp.edit().putString("history", neu.toString()).apply()
        } catch (e: Exception) { }
    }

    private fun showHistory() {
        val arr = try { JSONArray(hp.getString("history", "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() == 0) { toast("ইতিহাস খালি"); return }
        val fmt = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault())
        val labels = Array(arr.length()) {
            val o = arr.getJSONObject(it)
            o.optString("t") + "\n" + fmt.format(java.util.Date(o.optLong("ts"))) + " • " + o.optString("u")
        }
        AlertDialog.Builder(this).setTitle("ইতিহাস")
            .setItems(labels) { _, i -> web.loadUrl(arr.getJSONObject(i).optString("u")) }
            .setNeutralButton("সব মুছো") { _, _ -> hp.edit().remove("history").apply(); toast("ইতিহাস মুছে গেছে") }
            .setNegativeButton("বন্ধ", null).show()
    }

    private fun enqueue(url: String, ua: String? = null, mime: String? = null, disp: String? = null) {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) { toast("এই ধরনের লিংক ডাউনলোড করা যায় না"); return }
        try {
            val name = URLUtil.guessFileName(url, disp, mime)
            val r = DownloadManager.Request(Uri.parse(url))
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.addRequestHeader("User-Agent", ua ?: web.settings.userAgentString)
            web.url?.let { r.addRequestHeader("Referer", it) }
            r.setTitle(name)
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            toast("ডাউনলোড শুরু: $name")
        } catch (e: Exception) { toast("ডাউনলোড শুরু করা যায়নি: " + (e.message ?: "")) }
    }

    private fun probe(u: String, ua: String): String {
        return try {
            val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 4000; c.readTimeout = 4000
            c.setRequestProperty("User-Agent", ua)
            val len = c.contentLengthLong; val type = c.contentType ?: ""
            c.disconnect()
            (if (type.startsWith("audio")) "🎵 " else "🎬 ") + (if (len > 0) String.format("%.1f MB", len / 1048576.0) else "সাইজ অজানা")
        } catch (e: Exception) { "🎬" }
    }

    private fun showMedia() {
        web.evaluateJavascript(scanJs) { res ->
            try {
                val inner = JSONTokener(res ?: "null").nextValue() as? String
                if (inner != null) { val a = JSONArray(inner); for (k in 0 until a.length()) found[a.getString(k)] = "m" }
            } catch (e: Exception) { }
            val urls = synchronized(found) { found.keys.toList() }.takeLast(30).reversed()
            if (urls.isEmpty()) { presentMedia(urls, emptyList()); return@evaluateJavascript }
            toast("খোঁজা হচ্ছে...")
            val ua = web.settings.userAgentString
            Thread {
                val labels = urls.map { probe(it, ua) + "\n" + URLUtil.guessFileName(it, null, null) }
                runOnUiThread { presentMedia(urls, labels) }
            }.start()
        }
    }

    private fun presentMedia(urls: List<String>, labels: List<String>) {
        val b = AlertDialog.Builder(this).setTitle("ভিডিও / অডিও ডাউনলোড")
        if (urls.isEmpty())
            b.setMessage("এই পেজে সরাসরি ডাউনলোডযোগ্য ভিডিও/অডিও পাওয়া যায়নি।\n\nভিডিও চালু করে আবার চেষ্টা করো, অথবা নিচে সরাসরি ফাইলের লিংক পেস্ট করো।\n\n(YouTube/Facebook-এর মতো সাইটের স্ট্রিম এখানে ধরা পড়ে না।)")
        else
            b.setItems(labels.toTypedArray()) { _, i -> enqueue(urls[i]) }
        b.setNeutralButton("লিংক পেস্ট") { _, _ -> askLink() }
        b.setNegativeButton("বন্ধ", null).show()
    }

    private fun askLink() {
        val et = EditText(this).apply { hint = "https://... ফাইলের সরাসরি লিংক"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("লিংক থেকে ডাউনলোড").setView(et)
            .setPositiveButton("ডাউনলোড") { _, _ -> enqueue(et.text.toString().trim()) }
            .setNegativeButton("বাতিল", null).show()
    }

    private fun clip(label: String, text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
    }

    // এই পেজের সাইটের সব কুকি (নাম, মান) জোড়া আকারে
    private fun cookiePairs(): List<Pair<String, String>> {
        CookieManager.getInstance().flush()
        val ck = CookieManager.getInstance().getCookie(web.url ?: "") ?: return emptyList()
        return ck.split(";").map { it.trim() }.filter { it.contains("=") }
            .map { Pair(it.substringBefore("=").trim(), it.substringAfter("=").trim()) }
    }

    private fun copyCookies() {
        val pairs = cookiePairs()
        val u = web.url ?: ""
        if (pairs.isEmpty()) { toast("এই সাইটের কোনো কুকি নেই"); return }
        val host = Uri.parse(u).host ?: ""
        val labels = arrayOf(
            "📋 সাধারণ (Cookie হেডার)",
            "🧾 JSON",
            "📄 Netscape cookies.txt (yt-dlp / curl-এর জন্য)",
            "🗑 এই সাইটের কুকি মুছে ফেলো"
        )
        AlertDialog.Builder(this).setTitle("কুকিজ — $host (${pairs.size}টি)")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> { clip("cookies", pairs.joinToString("; ") { it.first + "=" + it.second }); toast("কুকিজ কপি হয়েছে") }
                    1 -> {
                        val arr = JSONArray()
                        pairs.forEach { arr.put(JSONObject().put("name", it.first).put("value", it.second).put("domain", host).put("path", "/")) }
                        clip("cookies-json", arr.toString(2)); toast("JSON কপি হয়েছে")
                    }
                    2 -> {
                        val dom = "." + host.removePrefix("www.")
                        val secure = if (u.startsWith("https")) "TRUE" else "FALSE"
                        val exp = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
                        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
                        pairs.forEach { sb.append(dom).append("\tTRUE\t/\t").append(secure).append("\t").append(exp).append("\t").append(it.first).append("\t").append(it.second).append("\n") }
                        clip("cookies-txt", sb.toString()); toast("cookies.txt কপি হয়েছে")
                    }
                    3 -> AlertDialog.Builder(this).setTitle("কুকি মুছবে?").setMessage("এই সাইট থেকে লগইন থাকলে বের হয়ে যাবে।")
                        .setPositiveButton("মুছো") { _, _ ->
                            val cmg = CookieManager.getInstance()
                            pairs.forEach { cmg.setCookie(u, it.first + "=; Max-Age=0; Path=/") }
                            cmg.flush(); toast("কুকি মুছে গেছে"); web.reload()
                        }.setNegativeButton("বাতিল", null).show()
                    else -> {}
                }
            }
            .setNegativeButton("বন্ধ", null).show()
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        val items = listOf("↻ রিফ্রেশ", "🕘 ইতিহাস", "⬇ ডাউনলোড লিস্ট", "🎬 ভিডিও/অডিও ডাউনলোড", "🍪 কুকিজ কপি", "🔗 লিংক কপি",
            "🖥 ডেস্কটপ সাইট" + (if (desktop) " ✓" else ""), "↗ অন্য ব্রাউজারে খোলো")
        items.forEachIndexed { i, t -> pm.menu.add(0, i, i, t) }
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                0 -> web.reload()
                1 -> showHistory()
                2 -> try { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) } catch (e: Exception) { toast("ডাউনলোড ফোল্ডার খোলা যায়নি") }
                3 -> showMedia()
                4 -> copyCookies()
                5 -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", web.url ?: "")); toast("লিংক কপি হয়েছে")
                }
                6 -> { desktop = !desktop; web.settings.userAgentString = if (desktop) desktopUa else mobileUa; web.reload() }
                7 -> openExternal()
            }
            true
        }
        pm.show()
    }

    private fun handleOther(v: WebView, u: String) {
        val scheme = Uri.parse(u).scheme ?: ""
        if (u.startsWith("intent://")) { // অন্য অ্যাপ নয়, fallback লিংক এখানেই খোলো
            val m = Regex("browser_fallback_url=([^;]+)").find(u)
            v.loadUrl(if (m != null) Uri.decode(m.groupValues[1]) else "https://" + u.removePrefix("intent://").substringBefore("#Intent"))
        } else if (scheme in listOf("tel", "mailto", "sms", "geo")) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { }
        }
        // বাকি অ্যাপ-স্কিম ব্লক
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cur = this
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0B0F24")); setPadding(dp(4), 0, dp(4), 0)
        }
        // লিংক দেখানোর বার
        urlText = TextView(this).apply {
            textSize = 13f; setTextColor(Color.parseColor("#DDE3FF")); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            background = GradientDrawable().apply { setColor(Color.parseColor("#1A2040")); cornerRadius = dp(18).toFloat() }
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("url", web.url ?: ""))
                Toast.makeText(this@BrowserActivity, "লিংক কপি হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
        val openExt = TextView(this).apply {
            text = "⋮"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(12), 0); setOnClickListener { showMenu(it) }
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(12), 0); setOnClickListener { finish() }
        }
        top.addView(urlText, LinearLayout.LayoutParams(0, dp(36), 1f))
        top.addView(openExt, LinearLayout.LayoutParams(-2, -1))
        top.addView(close, LinearLayout.LayoutParams(-2, -1))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(bar, LinearLayout.LayoutParams(-1, dp(3)))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        frame = FrameLayout(this).apply { addView(root, FrameLayout.LayoutParams(-1, -1)) }
        setContentView(frame)

        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true); javaScriptCanOpenWindowsAutomatically = true
            useWideViewPort = true; loadWithOverviewMode = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            // কিছু সাইট ("wv" দেখলে) WebView ব্লক করে — তাই সাধারণ মোবাইল ব্রাউজারের মতো পরিচয় দেওয়া হয়
            userAgentString = userAgentString.replace("; wv", "").replace(Regex(" Version/\\d+\\.\\d+"), "")
            mobileUa = userAgentString
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }

        web.setDownloadListener { url, ua, cd, mime, _ -> enqueue(url, ua, mime, cd) }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val sch = r.url.scheme ?: ""
                if (sch == "http" || sch == "https") return false
                handleOther(v, r.url.toString())
                return true
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val u = r.url.toString()
                if ((u.startsWith("http://") || u.startsWith("https://")) && mediaExt.containsMatchIn(u) && found.size < 60) found[u] = "m"
                return null
            }
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { bar.visibility = View.VISIBLE; showUrl(url); found.clear() }
            override fun onPageFinished(v: WebView, url: String?) { bar.visibility = View.GONE; showUrl(url); addHistory(v.title, url) }
            override fun doUpdateVisitedHistory(v: WebView, url: String?, isReload: Boolean) { showUrl(url) }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { bar.progress = p }
            // নতুন উইন্ডো/ট্যাবে খোলার লিংকও এই ব্রাউজারেই খুলবে
            override fun onCreateWindow(v: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                val tmp = WebView(this@BrowserActivity)
                var done = false
                fun grab(u: String?) {
                    if (done || u.isNullOrBlank() || u == "about:blank") return
                    done = true
                    if (u.startsWith("http://") || u.startsWith("https://")) web.loadUrl(u) else handleOther(web, u)
                    Handler(Looper.getMainLooper()).post { try { tmp.destroy() } catch (e: Exception) { } }
                }
                tmp.settings.javaScriptEnabled = true
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(w: WebView, r: WebResourceRequest): Boolean { grab(r.url.toString()); return true }
                    override fun shouldInterceptRequest(w: WebView, r: WebResourceRequest): WebResourceResponse? {
                        if (r.isForMainFrame) { val u = r.url.toString(); Handler(Looper.getMainLooper()).post { grab(u) } }
                        return null
                    }
                    override fun onLoadResource(w: WebView, url: String?) { grab(url) }
                    override fun onPageStarted(w: WebView, url: String?, f: Bitmap?) { grab(url) }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null); fileCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCb = cb
                frame.addView(view, FrameLayout.LayoutParams(-1, -1))
            }
            override fun onHideCustomView() {
                customView?.let { frame.removeView(it) }
                customView = null; customCb?.onCustomViewHidden(); customCb = null
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) web.webChromeClient?.onHideCustomView()
                else if (web.canGoBack()) web.goBack() else finish()
            }
        })
        val url = intent.getStringExtra("url")
        if (url != null) { showUrl(url); web.loadUrl(url) } else finish()
    }

    override fun onStart() { super.onStart(); TimerState.visibleCount++ }
    override fun onStop() { TimerState.visibleCount--; super.onStop() }

    override fun onDestroy() {
        if (cur === this) cur = null
        try { web.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
